From Data to Thesis: Research Data Analysis with R
Playground, Chapter 6: Hypothesis Testing and Statistical Inference

How to use this project
1. Double-click chapter06.Rproj. RStudio opens with this folder as the working directory.
2. Open exercises.R and work through the exercises. Run a line with Ctrl+Enter.
3. Check your answers in solutions.R, after you have tried each exercise yourself.

The exercises need these packages (install once):
install.packages("dplyr")

Files
- exercises.R        the exercises, with starter code
- solutions.R        one possible solution for each exercise
- students.csv       one row per student in Elaf's study (600 students)
- semesters.csv      one row per student per semester

The data is simulated for teaching and describes no real people.
Exercises 1 to 6 can also be done in your browser at:
https://polla-fattah.github.io/R4NTR/playground/chapter06.html
